﻿namespace Client.Model
{
    public class LoggingModel
    {
        public string MyName { get; set; }
        public string MyIp { get; set; }
        public string HostIp { get; set; }
        public string HostPort { get; set; }

    }
}